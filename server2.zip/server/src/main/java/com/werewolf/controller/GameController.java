package com.werewolf.controller;

/**
 * Created by justin on 7/28/18.
 */

import com.werewolf.exceptions.IllegalRoomStateException;
import com.werewolf.model.request.InitGameRequest;
import com.werewolf.services.game.GameManagementService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class GameController {
    private static final Logger LOG = LogManager.getLogger(GameController.class);

    private final GameManagementService gameManagementService;

    @Autowired
    public GameController(GameManagementService gameManagementService) {
        this.gameManagementService = gameManagementService;
    }

    @RequestMapping(path = "/initGame", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    public ResponseEntity<Integer> initGame(@RequestBody InitGameRequest request) {
        String username = request.getUsername();
        LOG.info("user {} request to init new game", username);
        int roomNo;
        // room creating
        roomNo = gameManagementService.createNewGame(request);

        LOG.info("New room {} created.", roomNo);
        // host joining
        gameManagementService.playerJoinRoom(username, roomNo);
        LOG.info("user {} joined room {}", username, roomNo);
        return new ResponseEntity<>(roomNo, HttpStatus.OK);
    }

    @RequestMapping(path = "/joinGame", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    public ResponseEntity<String> joinGame(@RequestParam Integer roomNo, @RequestParam String username) {
        LOG.info("user {} request to join game {}", username, roomNo);
        try {
            gameManagementService.playerJoinRoom(username, roomNo);
        } catch (IllegalRoomStateException e) {
            LOG.error(e.getMessage());
            return new ResponseEntity<>(e.getMessage(), HttpStatus.OK);
        }
        //create new socket endpoint and subscribe the user
        return new ResponseEntity<>(HttpStatus.OK);
    }


    @RequestMapping(path = "/shuffleRoles", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    public ResponseEntity<String> shuffleRoles(@RequestParam Integer roomNo, @RequestParam String username) {
        gameManagementService.shuffleRoles(roomNo);
        //publich shuffle event
        return new ResponseEntity<>(HttpStatus.OK);
    }


    @RequestMapping(path = "/pickSeat/{seatNo}", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    public ResponseEntity<String> pickSeat(@RequestParam String username,@RequestParam Integer roomNo, @PathVariable Integer seatNo) {
        gameManagementService.assignSeatForUser(username, roomNo, seatNo);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(path = "/startGame", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    public ResponseEntity<String> startGame(@RequestParam String username,@RequestParam Integer roomNo ) {
        gameManagementService.startGame(username,roomNo);
        return new ResponseEntity<>(HttpStatus.OK);

    }

}