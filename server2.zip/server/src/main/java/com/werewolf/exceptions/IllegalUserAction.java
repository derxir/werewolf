package com.werewolf.exceptions;

public class IllegalUserAction extends RuntimeException {
    String message;

    public IllegalUserAction() {
        super();
    }

    public IllegalUserAction(String message) {
        this.message = message;
    }
}

