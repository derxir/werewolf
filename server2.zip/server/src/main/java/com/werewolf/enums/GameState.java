package com.werewolf.enums;

public enum GameState {
    STARTED,
    NEW
}
