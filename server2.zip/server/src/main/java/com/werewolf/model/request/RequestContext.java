package com.werewolf.model.request;

import com.werewolf.model.roles.Role;

import java.io.Serializable;

public abstract class RequestContext implements Serializable {
    private String username;

    private Role userRole;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Role getUserRole() {
        return userRole;
    }

    public void setUserRole(Role userRole) {
        this.userRole = userRole;
    }

}
