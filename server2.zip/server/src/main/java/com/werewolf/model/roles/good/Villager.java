package com.werewolf.model.roles.good;

public class Villager extends GoodRole {

    @Override
    public boolean visibleToSeer() {
        return true;
    }

    public boolean hasSkill() {
        return false;
    }
}
