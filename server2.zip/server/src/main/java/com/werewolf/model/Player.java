package com.werewolf.model;

import com.werewolf.model.roles.Role;

public class Player {

    private final String username;
    private int seatNo;
    private Role role;
    private boolean alive;
    private boolean roleRevealed;

    public Player(String username) {
        this.username = username;
        this.alive = true;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public boolean isAlive() {
        return alive;
    }

    public void getKilledByWolf() {
        alive = false;
    }


    public int getSeatNo() {
        return seatNo;
    }

    public void setSeatNo(int seatNo) {
        this.seatNo = seatNo;
    }

    public String getUsername() {
        return username;
    }

    public boolean isRoleRevealed() {
        return roleRevealed;
    }

    public void setRoleRevealed(boolean roleRevealed) {
        this.roleRevealed = roleRevealed;
    }
}
