package com.werewolf.model.roles;

public abstract class Role {

    public abstract boolean visibleToSeer();

    public abstract boolean hasSkill();

    public String getName(){
        return this.getClass().getSimpleName();
    }

    public abstract boolean isGoodRole();
}
