package com.werewolf.model.roles.good;

public class Witch extends GoodRole {

    @Override
    public boolean visibleToSeer() {
        return false;
    }

    @Override
    public boolean hasSkill() {
        return true;
    }
}
