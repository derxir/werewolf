package com.werewolf.model.roles.bad;

import com.werewolf.model.roles.Role;

public abstract class BadRole extends Role {

    public boolean isGoodRole() {
        return false;
    }
}
