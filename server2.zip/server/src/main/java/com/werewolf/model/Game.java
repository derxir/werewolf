package com.werewolf.model;

import com.werewolf.enums.GameState;
import com.werewolf.model.roles.Role;
import com.werewolf.model.roles.bad.WhiteWolf;
import com.werewolf.model.roles.bad.Wolf;
import com.werewolf.model.roles.good.Guardian;
import com.werewolf.model.roles.good.Hunter;
import com.werewolf.model.roles.good.Idiot;
import com.werewolf.model.roles.good.Seer;
import com.werewolf.model.roles.good.Villager;
import com.werewolf.model.roles.good.Witch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Game Session keeping all game states.
 */
public class Game {

    private String hostUser;
    private List<Integer> roleProxyIndices; // abstraction of role array
    private Map<String, Player> username2Player;
    private Map<Integer, Player> seatNo2Player;
    private List<Role> roles;
    private List<String> usernames;
    private GameState state;
    private int roomId;
    private AtomicInteger joinedPlayers;
    private AtomicInteger assignedRoles;
    private int nightCounter;
    private long creationTs;

    public void addPlayer(String username, Player player) {
        this.username2Player.put(username, player);
    }

    public int size() {
        return getRoles().size();
    }

    public Role getNextUnassignedRole() {
        int rolePointer = this.roleProxyIndices.get(assignedRoles.getAndIncrement());
        return getRoles().get(rolePointer);
    }

    public Map<String, Player> getUsername2Player() {
        return username2Player;
    }

    public Map<Integer, Player> getSeatNo2Player() {
        return seatNo2Player;
    }

    public int getRoomId() {
        return roomId;
    }

    public GameState getState() {
        return state;
    }

    public List<Integer> getRoleProxyIndices() {
        return roleProxyIndices;
    }

    public void setRoleProxyIndices(List<Integer> roleProxyIndices) {
        this.roleProxyIndices = roleProxyIndices;
    }

    public String getHostUser() {
        return hostUser;
    }

    public void setHostUser(String hostUser) {
        this.hostUser = hostUser;
    }

    public int getNightCounter() {
        return nightCounter;
    }

    public List<String> getUsernames() {
        return usernames;
    }

    public void setUsernames(List<String> usernames) {
        this.usernames = usernames;
    }

    public boolean isFull() {
        return this.joinedPlayers.get() >= size();
    }

    public List<Role> getRoles() {
        return this.roles;
    }

    public AtomicInteger getJoinedPlayers() {
        return joinedPlayers;
    }

    /**
     * @param username
     * @return total number of username2Player after registration
     */
    public int RegisterPlayerUsername(String username) {
        this.getUsernames().add(username);
        return getJoinedPlayers().getAndIncrement();
    }

    public Player getPlayerByUsername(String username) {
        return username2Player.get(username);
    }

    public Player getPlayerBySeatNo(Integer seatNo) {
        return seatNo2Player.get(seatNo);
    }

    public boolean start() {
        state = GameState.STARTED;
        return true;
    }

    public static class Builder {
        private List<Role> roles;

        public Builder() {
            roles = new ArrayList<>();
        }

        public Builder wolf(int number) {
            for (int i = 0; i < number; i++) {
                roles.add(new Wolf());
            }
            return this;
        }

        public Builder villager(int number) {
            for (int i = 0; i < number; i++) {
                roles.add(new Villager());
            }
            return this;
        }

        public Builder withSeer(boolean hasSeer) {
            if (hasSeer) roles.add(new Seer());
            return this;
        }

        public Builder withIdiot(boolean hasIdiot) {
            if (hasIdiot) roles.add(new Idiot());
            return this;
        }

        public Builder withWitch(boolean hasWitch) {
            if (hasWitch) roles.add(new Witch());
            return this;
        }

        public Builder withHunter(boolean hasHunter) {
            if (hasHunter) roles.add(new Hunter());
            return this;
        }

        public Builder withGuardian(boolean hasGuardian) {
            if (hasGuardian) roles.add(new Guardian());
            return this;
        }

        public Builder withWhiteWolf(boolean hasWhiteWolf) {
            if (hasWhiteWolf) roles.add(new WhiteWolf());
            return this;
        }

        public Game build() {
            Game game = new Game();
            game.roles = this.roles;
            game.state = GameState.NEW;
            game.nightCounter = 0;
            game.username2Player = new HashMap<>();
            game.seatNo2Player = new HashMap<>();
            game.joinedPlayers = new AtomicInteger();
            game.assignedRoles = new AtomicInteger();
            game.usernames = new ArrayList<>();
            game.roleProxyIndices = IntStream.range(0, game.roles.size()).boxed().collect(Collectors.toList());
            game.creationTs = System.currentTimeMillis();
            return game;
        }

    }
}
