package com.werewolf.model.request;

public class InitGameRequest extends RequestContext {

    private int total;

    /**
     * Special good roles
     */
    private boolean hasSeer;
    private boolean hasWitch;
    private boolean hasHunter;
    private boolean hasIdiot;
    private boolean hasGuardian;

    /**
     * Non-special good roles
     */
    private int villagerQuantity;

    /**
     * Special bad roles
     */
    private boolean hasWhiteWolf;

    /**
     * Non-special bad roles
     */
    private int WolfQuantity;


    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public boolean isHasSeer() {
        return hasSeer;
    }

    public void setHasSeer(boolean hasSeer) {
        this.hasSeer = hasSeer;
    }

    public boolean isHasWitch() {
        return hasWitch;
    }

    public void setHasWitch(boolean hasWitch) {
        this.hasWitch = hasWitch;
    }

    public boolean isHasHunter() {
        return hasHunter;
    }

    public void setHasHunter(boolean hasHunter) {
        this.hasHunter = hasHunter;
    }

    public boolean isHasIdiot() {
        return hasIdiot;
    }

    public void setHasIdiot(boolean hasIdiot) {
        this.hasIdiot = hasIdiot;
    }

    public boolean isHasGuardian() {
        return hasGuardian;
    }

    public void setHasGuardian(boolean hasGuardian) {
        this.hasGuardian = hasGuardian;
    }

    public int getVillagerQuantity() {
        return villagerQuantity;
    }

    public void setVillagerQuantity(int villagerQuantity) {
        this.villagerQuantity = villagerQuantity;
    }

    public boolean isHasWhiteWolf() {
        return hasWhiteWolf;
    }

    public void setHasWhiteWolf(boolean hasWhitewolf) {
        this.hasWhiteWolf = hasWhitewolf;
    }

    public int getWolfQuantity() {
        return WolfQuantity;
    }

    public void setWolfQuantity(int wolfQuantity) {
        WolfQuantity = wolfQuantity;
    }


}
