package com.werewolf.services.game;

import com.werewolf.cache.GameUserRegistry;
import com.werewolf.cache.GlobalGameSessionCacheStore;
import com.werewolf.exceptions.IllegalRoomStateException;
import com.werewolf.exceptions.IllegalUserAction;
import com.werewolf.model.Game;
import com.werewolf.model.Player;
import com.werewolf.model.request.InitGameRequest;
import com.werewolf.model.roles.Role;
import com.werewolf.services.user.UserTrackingService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Service
public class GameManagementService {
    private static final Logger LOG = LogManager.getLogger(GameManagementService.class);

    private final
    GlobalGameSessionCacheStore gameSessionCache;

    private final
    UserTrackingService userTrackingService;

    private final
    GameUserRegistry gameUserRegistry;


    @Autowired
    public GameManagementService(GlobalGameSessionCacheStore gameSessionCache, UserTrackingService userTrackingService, GameUserRegistry gameUserRegistry) {
        this.gameSessionCache = gameSessionCache;
        this.userTrackingService = userTrackingService;
        this.gameUserRegistry = gameUserRegistry;
    }

    public int createNewGame(InitGameRequest request) throws IllegalUserAction {
        String requestUser = request.getUsername();
        if (gameUserRegistry.checkHostRegistered(requestUser))
            throw new IllegalUserAction("User " + requestUser + "cannot create more than one room.");

        Game game = new Game.Builder()
                .villager(request.getVillagerQuantity())
                .wolf(request.getWolfQuantity())
                .withSeer(request.isHasSeer())
                .withWitch(request.isHasWitch())
                .withHunter(request.isHasHunter())
                .withIdiot(request.isHasIdiot())
                .withGuardian(request.isHasGuardian())
                .withWhiteWolf(request.isHasWhiteWolf())
                .build();
        int roomNo = getNewRoomNo(game);
        gameUserRegistry.registerHost(requestUser, roomNo);
        shuffleRoles(roomNo);
        return roomNo;
    }

    /**
     * @param game
     * @return new room id if succeeded caching
     */
    private int getNewRoomNo(Game game) {
        int roomId;
        do {
            roomId = generateRoomNo();
        } while (gameSessionCache.contains(roomId));

        long ts = System.currentTimeMillis();
        gameSessionCache.put(roomId, game);
        return roomId;
    }

    public void playerJoinRoom(String username, int roomNo) throws IllegalRoomStateException {
        Game game = gameSessionCache.get(roomNo);
        if (game == null) throw new IllegalRoomStateException("Room does not exist!");
        if (game.isFull()) throw new IllegalRoomStateException("Room is full.");
        synchronized (game) {
//            String host = game.getHostUser();
//            List<String> joinedPlayers = gameUserRegistry.registerPlayerUsername(host, username); //rethink
            game.RegisterPlayerUsername(username);
            Role role = game.getNextUnassignedRole();
            Player player = new Player(username);
            player.setRole(role);
            game.addPlayer(username, player);
        }
    }

    private int generateRoomNo() {
        return (int) (Math.random() * 1000000);
    }

    public void shuffleRoles(int roomNo) {
        LOG.info("Shuffle roles for room {}", roomNo);
        List<Integer> roleProxy = gameSessionCache.get(roomNo).getRoleProxyIndices();
        LOG.info("old role mapping {}", roleProxy);
        Collections.shuffle(roleProxy);
        LOG.info("new role mapping {}", roleProxy);
    }

    public boolean assignSeatForUser(String username, Integer roomNo, Integer seatNo) {
        Game game = gameSessionCache.get(roomNo);
        if (game == null) throw new IllegalRoomStateException("Room does not exist!");
        synchronized (game) {
            Player thisPlayer = game.getPlayerByUsername(username);
            thisPlayer.setSeatNo(seatNo);
        }
        return true;
    }

    public boolean startGame(String username, Integer roomNo) throws IllegalRoomStateException, IllegalUserAction {
        Game game = gameSessionCache.get(roomNo);

        if (game == null) throw new IllegalRoomStateException("Room does not exist!");
        if (!username.equals(game.getHostUser())) throw new IllegalUserAction("Only host can start the game.");
        if (!game.isFull()) throw new IllegalRoomStateException("Room is not full.");
        if (game.getSeatNo2Player().size() != game.size()) throw new IllegalRoomStateException("Someone is not seated");

        Collection<Player> allPlayers = game.getSeatNo2Player().values();
        boolean isAllPlayerRevealTheirRoles = allPlayers.stream()
                .map(Player::isRoleRevealed)
                .reduce((b1, b2) -> b1 && b2).get();
        if (!isAllPlayerRevealTheirRoles) throw new IllegalRoomStateException("Someone has not seen his role");

        return true;
    }
}
