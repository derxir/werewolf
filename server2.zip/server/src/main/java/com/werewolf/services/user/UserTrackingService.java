package com.werewolf.services.user;


import org.springframework.stereotype.Component;

@Component
public class UserTrackingService {
}
