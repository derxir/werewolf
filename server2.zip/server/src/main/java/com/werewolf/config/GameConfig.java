package com.werewolf.config;

import com.werewolf.cache.GlobalGameSessionCacheStore;
import com.werewolf.cache.GameUserRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GameConfig {

    @Bean
    public GameUserRegistry userRegistry(){
        return new GameUserRegistry();
    }

    @Bean
    public GlobalGameSessionCacheStore globalGameSessionCacheStore(){
        return new GlobalGameSessionCacheStore();
    }
}
