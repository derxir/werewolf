package com.werewolf.cache;

import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

@Repository
public class GameUserRegistry {

    private Map<String,Integer> activeHosts2Room = new HashMap<>();

    private Map<String, List<String>> host2players = new LinkedHashMap<>();
    /**
     * register host
     * @param username
     * @return true if added, false if already exist
     */
    public boolean registerHost(String username, int roomNo){
        if(checkHostRegistered(username)){
            return false;
        }
        activeHosts2Room.put(username, roomNo);
        return true;
    }

    public boolean checkHostRegistered(String username){
        return activeHosts2Room.containsKey(username);
    }
    public List<String> registerPlayerUsername(String host, String player){
        List<String> players;
        if((players = host2players.get(host)) == null){
            players = new LinkedList<>();
        }
        players.add(player);
        return players;
    }
}
