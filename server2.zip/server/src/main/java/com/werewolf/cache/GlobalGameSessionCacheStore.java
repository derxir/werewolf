package com.werewolf.cache;

import com.werewolf.model.Game;
import org.springframework.stereotype.Repository;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * effectively a session cache manager
 */
@Repository
public class GlobalGameSessionCacheStore implements CacheStore<Integer, Game> {

    private Map<Integer, Game> cache;

    public GlobalGameSessionCacheStore() {
        cache = new ConcurrentHashMap<>(); // for the sake of simplicity for now
    }

//    public static GlobalGameSessionCacheStore getInstance() {
//        return Inner.INSTANCE;
//    }

    public void setCache(Map<Integer, Game> cache) {
        this.cache = cache;
    }

    @Override
    public void load(Iterable<? extends Integer> keys) {
        //TODO to be extended
    }

    @Override
    public Game get(Integer key) {
        return this.cache.get(key);
    }

    @Override
    public Game put(Integer key, Game value) {
        return this.cache.put(key, value);
    }

    @Override
    public boolean contains(Integer key) {
        return this.cache.containsKey(key);
    }

    private static class Inner {
        private static final GlobalGameSessionCacheStore INSTANCE = new GlobalGameSessionCacheStore();
    }

    private class CacheKey {
        private final int roomId;

        /* for expiry policy concern */
        private final long creationTs;

        private CacheKey(int roomId, long creationTs) {
            this.roomId = roomId;
            this.creationTs = creationTs;
        }
    }
}
