package com.werewolf.cache;

/**
 * API for cache persistent storage for read-through and write-through behavior.
 *
 * @param <K>
 * @param <V>
 */
public interface CacheStore<K, V>{
    /**
     * load cache from underlying persistent storage.
     *
     * @param keys
     */
    void load(Iterable<? extends K> keys);

    /**
     * get value from cache
     * @param key
     * @return null if none key is found
     */
    V get(K key);

    /**
     * put a new entry into cache
     * @param key
     * @param value
     * @return
     */
    V put(K key, V value);

    boolean contains(K key);
}
