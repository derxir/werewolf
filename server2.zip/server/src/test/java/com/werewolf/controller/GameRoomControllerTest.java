package com.werewolf.controller;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.fluent.Request;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class GameRoomControllerTest {

    private static final String INIT_URL = "http://localhost:8080/initGame";
    private static final String JOIN_URL = "http://localhost:8080/joinGame";
    private static final String SEAT_URL = "http://localhost:8080/pickSeat/12";
    private static final String START_URL = "http://localhost:8080/startGame";
    private static final String requestFile = "requests/initGame.json";
    private static String roomNo;
    @Test
    public void initGameSessionThen200() throws IOException {
        String json = IOUtils.toString(getClass().getClassLoader().getResourceAsStream(requestFile));
        Request httpRequest = Request.Post(INIT_URL)
                 .setHeader("Accept", "application/json")
                 .setHeader("Content-type", "application/json")
                .body(new StringEntity(json));

        System.out.println("Sending POST request:" + httpRequest);
        HttpResponse httpResponse = httpRequest.execute().returnResponse();

        String body = EntityUtils.toString(httpResponse.getEntity());
        roomNo = body;
        assertEquals(httpResponse.getStatusLine().getStatusCode(), 200);
    }

    @Test
    public void joinGameThen200() throws IOException {
        CloseableHttpClient client = HttpClients.createDefault();
        HttpPost httpRequest = new HttpPost(JOIN_URL);

        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("username", "test-user3"));
        params.add(new BasicNameValuePair("roomNo", "697087"));
        httpRequest.setEntity(new UrlEncodedFormEntity(params));

        System.out.println("Sending POST request:" + httpRequest);
        CloseableHttpResponse httpResponse = client.execute(httpRequest);
//        HttpResponse httpResponse = httpRequest.execute().returnResponse();
        assertEquals(httpResponse.getStatusLine().getStatusCode(), 200);
    }


    @Test
    public void pickSeatThen200() throws IOException {
        CloseableHttpClient client = HttpClients.createDefault();
        HttpPost httpRequest;
        httpRequest = new HttpPost(SEAT_URL);

        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("username", "test-user3"));
        params.add(new BasicNameValuePair("roomNo", "697087"));
        httpRequest.setEntity(new UrlEncodedFormEntity(params));

        System.out.println("Sending POST request:" + httpRequest);
        CloseableHttpResponse httpResponse = client.execute(httpRequest);
        assertEquals(httpResponse.getStatusLine().getStatusCode(), 200);
    }

    @Test
    public void startGameThen200() throws IOException {
        CloseableHttpClient client = HttpClients.createDefault();
        HttpPost httpRequest;
        httpRequest = new HttpPost(START_URL);

        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("username", "test-user"));
        params.add(new BasicNameValuePair("roomNo", "190474"));
        httpRequest.setEntity(new UrlEncodedFormEntity(params));

        System.out.println("Sending POST request:" + httpRequest);
        CloseableHttpResponse httpResponse = client.execute(httpRequest);
        assertEquals(httpResponse.getStatusLine().getStatusCode(), 200);
    }
}