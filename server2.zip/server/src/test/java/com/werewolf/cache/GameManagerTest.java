//package com.werewolf.cache;
//
//import com.werewolf.model.Game;
//import org.easymock.EasyMockRunner;
//import org.easymock.Mock;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//
//import java.util.List;
//import java.util.Map;
//import java.util.stream.Collectors;
//import java.util.stream.IntStream;
//
//import static org.easymock.EasyMock.expect;
//import static org.easymock.EasyMock.replay;
//
//@RunWith(EasyMockRunner.class)
//public class GameManagerTest {
//    @Mock
//    private Game game;
//
//    @Mock
//    private Map<Integer, Game> cache;
//
//    @Test
//    public void shuffleRoles() {
//        GlobalGameSessionCacheStore manager = new GlobalGameSessionCacheStore();
//        manager.setCache(cache);
//        List<Integer> oldMapping = IntStream.rangeClosed(1, 10).boxed().collect(Collectors.toList());
//        int roomId = 123456;
//        expect(cache.get(roomId)).andReturn(game);
//        expect(game.getRoleProxyIndices()).andReturn(oldMapping);
//        replay(cache);
//        replay(game);
//
//        manager.shuffleRoles(roomId);
//    }
//}
