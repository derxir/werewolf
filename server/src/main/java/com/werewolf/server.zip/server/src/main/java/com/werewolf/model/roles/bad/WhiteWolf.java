package com.werewolf.model.roles.bad;

public class WhiteWolf extends BadRole {
    @Override
    public boolean visibleToSeer() {
        return true;
    }

    @Override
    public boolean hasSkill() {
        return true;
    }
}
