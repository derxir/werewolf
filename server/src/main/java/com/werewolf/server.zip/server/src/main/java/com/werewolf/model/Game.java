package com.werewolf.model;

import com.werewolf.enums.GameState;
import com.werewolf.model.roles.bad.WhiteWolf;
import com.werewolf.model.roles.bad.Wolf;
import com.werewolf.model.roles.good.Guardian;
import com.werewolf.model.roles.good.Hunter;
import com.werewolf.model.roles.good.Idiot;
import com.werewolf.model.roles.good.Seer;
import com.werewolf.model.roles.good.Villager;
import com.werewolf.model.roles.good.Witch;

import java.util.ArrayList;
import java.util.List;

/**
 * Game Session keeping all game states.
 * need mapping : player <-> username
 */
public class Game {

    /**
     * temporal mapping indices between
     */
    private List<Integer> mappings;
    private List<Player> players;
    private List<String> usernames;
    private GameState state;
    private int roomId;
    private int totalPlayers;
    private int nightCounter;
    private long creationTs;

    public List<Player> getPlayers() {
        return players;
    }

    public int getRoomId() {
        return roomId;
    }

    public GameState getState() {
        return state;
    }

    public List<Integer> getMappings() {
        return mappings;
    }

    public void setMappings(List<Integer> mappings) {
        this.mappings = mappings;
    }

    public int getNightCounter() {
        return nightCounter;
    }

    public void registerUsername(String username) {
        this.usernames.add(username);
    }

    public static class Builder {
        private List<Player> players;

        public Builder() {
            players = new ArrayList<>();
        }

        public Builder wolf(int number) {
            for (int i = 0; i < number; i++) {
                players.add(new Player(new Wolf()));
            }
            return this;
        }

        public Builder villager(int number) {
            for (int i = 0; i < number; i++) {
                players.add(new Player(new Villager()));
            }
            return this;
        }

        public Builder withSeer(boolean hasSeer) {
            if (hasSeer) players.add(new Player(new Seer()));
            return this;
        }

        public Builder withIdiot(boolean hasIdiot) {
            if (hasIdiot) players.add(new Player(new Idiot()));
            return this;
        }

        public Builder withWitch(boolean hasWitch) {
            if (hasWitch) players.add(new Player(new Witch()));
            return this;
        }

        public Builder withHunter(boolean hasHunter) {
            if (hasHunter) players.add(new Player(new Hunter()));
            return this;
        }

        public Builder withGuardian(boolean hasGuardian) {
            if (hasGuardian) players.add(new Player(new Guardian()));
            return this;
        }

        public Builder withWhiteWolf(boolean hasWhiteWolf) {
            if (hasWhiteWolf) players.add(new Player(new WhiteWolf()));
            return this;
        }

        public Game build() {
            Game game = new Game();
            game.players = this.players;
            game.state = GameState.NEW;
            game.nightCounter = 0;
            game.totalPlayers = players.size();
            game.usernames = new ArrayList<>();
            game.creationTs = System.currentTimeMillis();
            return game;
        }

    }


}
