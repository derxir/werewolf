package com.werewolf.model.roles.good;

import com.werewolf.model.Player;

public class Seer extends GoodRole {

    /**
     * Special skill: reveal ID of one player,
     * @return true if good, false if bad
     */
    public boolean see(Player player){
        return player.getRole().isGoodRole();
    }

    @Override
    public boolean visibleToSeer() {
        return true;
    }

    @Override
    public boolean hasSkill() {
        return true;
    }

    public boolean isGoodRole() {
        return true;
    }
}
