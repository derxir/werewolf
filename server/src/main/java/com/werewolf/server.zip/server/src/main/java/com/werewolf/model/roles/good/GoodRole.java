package com.werewolf.model.roles.good;

import com.werewolf.model.roles.Role;

public abstract class GoodRole extends Role {

    public boolean isGoodRole() {
        return true;
    }
}
