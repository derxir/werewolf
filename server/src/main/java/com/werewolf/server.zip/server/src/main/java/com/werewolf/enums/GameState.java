package com.werewolf.enums;

public enum GameState {

    NEW
}
