package com.werewolf.manager;

import com.werewolf.exceptions.IllegalRoomStateException;
import com.werewolf.model.Game;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * session cache manager
 */
@Component
public class GameManager {
    private static final Logger LOG = LogManager.getLogger(GameManager.class);

    private Map<Integer, Game> cache;

    public GameManager() {
        cache = new ConcurrentHashMap<>();
    }

    public void playerJoinRoom(String username, int roomId) {
        Game game ;
        if((game = cache.get(roomId))== null){
            throw new IllegalRoomStateException("Room does not exist!");
        }
    }

    private static class Inner {
        private static final GameManager INSTANCE = new GameManager();
    }
    public static GameManager getInstance() {
        return Inner.INSTANCE;
    }

    /**
     * caching
     * @param game
     * @return room ID
     */
    public int registerNewGame(Game game) {
        int roomId;
        do {
            roomId = generateRoomId();
        } while (cache.keySet().contains(roomId));

        long ts = System.currentTimeMillis();
        cache.put(roomId, game);
        return roomId;
    }

    public void shuffleRoles(int roomId){
        LOG.info("Shuffle roles for room {}", roomId);
        List<Integer> mappings = cache.get(roomId).getMappings();
        LOG.info("old role mapping {}", mappings);
        Collections.shuffle(mappings);
        LOG.info("new role mapping {}", mappings);

    }

    private int generateRoomId() {
        return (int) (Math.random() * 1000000);
    }


    public void setCache(Map<Integer, Game> cache) {
        this.cache = cache;
    }

    private class CacheKey {
        private final int roomId;

        /* for expiry policy concern */
        private final long creationTs;

        private CacheKey(int roomId, long creationTs) {
            this.roomId = roomId;
            this.creationTs = creationTs;
        }
    }
}
