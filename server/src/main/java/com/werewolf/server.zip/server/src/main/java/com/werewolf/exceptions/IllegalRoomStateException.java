package com.werewolf.exceptions;

public class IllegalRoomStateException extends RuntimeException {
    String message;

    public IllegalRoomStateException() {
        super();
    }

    public IllegalRoomStateException(String message) {
        this.message = message;
    }
}
