package com.werewolf.model.roles.good;

public class Idiot extends GoodRole {

    @Override
    public boolean visibleToSeer() {
        return true;
    }

    @Override
    public boolean hasSkill() {
        return false;
    }

    @Override
    public boolean isGoodRole() {
        return true;
    }
}
