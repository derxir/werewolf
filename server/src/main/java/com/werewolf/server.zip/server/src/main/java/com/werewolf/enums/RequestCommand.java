package com.werewolf.enums;

enum RequestCommand {
    CREATE_NEW_GAME,
    CONNECT_TO_GAME,
    WOLF_KILL;

}
