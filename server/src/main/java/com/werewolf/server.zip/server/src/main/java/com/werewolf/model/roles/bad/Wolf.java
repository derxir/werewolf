package com.werewolf.model.roles.bad;

public class Wolf extends BadRole {

    @Override
    public boolean visibleToSeer() {
        return true;
    }

    @Override
    public boolean hasSkill() {
        return false;
    }
}
