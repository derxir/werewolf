package com.werewolf.model.roles.good;

public class Hunter extends GoodRole {
    @Override
    public boolean visibleToSeer() {
        return true;
    }

    @Override
    public boolean hasSkill() {
        return true;
    }
}
