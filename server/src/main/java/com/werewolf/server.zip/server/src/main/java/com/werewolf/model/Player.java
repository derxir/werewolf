package com.werewolf.model;

import com.werewolf.model.roles.Role;

public class Player {

    private int id;

    private String username;

    private final Role role;

    private boolean alive;

    public Player(Role role) {
        this.role = role;
        this.alive = true;
    }

    public Role getRole() {
        return role;
    }

    public boolean isAlive() {
        return alive;
    }

    public void getKilledByWolf() {
        alive = false;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

}
