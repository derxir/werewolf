package com.werewolf.controller;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertEquals;

public class GameRoomControllerTest {

    private static final String INIT_URL = "http://localhost:8080/initGame";
    private static final String requestFile = "requests/initGame.json";

    @Test
    public void initGameSessionThen200() throws IOException {
        String json = IOUtils.toString(getClass().getClassLoader().getResourceAsStream(requestFile));
        Request httpRequest = Request.Post(INIT_URL)
                 .setHeader("Accept", "application/json")
                 .setHeader("Content-type", "application/json")
                .body(new StringEntity(json));

        System.out.println("Sending POST request:" + httpRequest);
        HttpResponse httpResponse = httpRequest.execute().returnResponse();
        String body2 = EntityUtils.toString(httpResponse.getEntity());
        System.out.println(httpResponse.getStatusLine().getStatusCode());
        System.out.println("Response Body: " + body2);
        assertEquals(httpResponse.getStatusLine().getStatusCode(), 200);
    }
}