package com.werewolf.controller;

/**
 * Created by justin on 7/28/18.
 */

import com.werewolf.exceptions.IllegalRoomStateException;
import com.werewolf.manager.GameManager;
import com.werewolf.model.Game;
import com.werewolf.model.request.InitGameRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class GameRoomController {
    private static final Logger LOG = LogManager.getLogger(GameRoomController.class);

    @Autowired
    private GameManager gameManager;

    public GameRoomController(GameManager manager) {
        this.gameManager = manager;
    }

    @RequestMapping(path = "/initGame", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    public ResponseEntity<Integer> initGame(@RequestParam String username, @RequestBody InitGameRequest request) {
        Game game = new Game.Builder()
                            .villager(request.getVillagerQuantity())
                            .wolf(request.getWolfQuantity())
                            .withSeer(request.isHasSeer())
                            .withWitch(request.isHasWitch())
                            .withHunter(request.isHasHunter())
                            .withIdiot(request.isHasIdiot())
                            .withGuardian(request.isHasGuardian())
                            .withWhiteWolf(request.isHasWhiteWolf())
                            .build();
        int roomId = gameManager.registerNewGame(game);
        LOG.info("New room {} created.",roomId);
        return new ResponseEntity<>(roomId, HttpStatus.OK);
    }

    @RequestMapping(path = "/joinGame", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    public ResponseEntity<String> joinGame(@RequestParam int roomId, @RequestParam String username){
        try{
            gameManager.playerJoinRoom(username, roomId);
        }catch(IllegalRoomStateException e){
            LOG.error(e.getMessage());
            return new ResponseEntity<>(e.getMessage(), HttpStatus.OK);
        }
        return new ResponseEntity<>("joined", HttpStatus.OK);
    }


}